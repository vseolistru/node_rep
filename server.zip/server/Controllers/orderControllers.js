import Order from "../models/Order.js";


class OrderControllers {

   async create (req, res) {
      try{
          const savedOrder = await Order.create(req.body);
          return res.json(savedOrder).status(200);
      }
      catch (e) {
           res.status(500).json("Something went wrong")
      }
   };

   async update (req, res) {
      try {
          const updateOrder = await Order.findByIdAndUpdate(
              req.params.id,
              {$set: req.body}, {new: true}
          );
          const {...data} = updateOrder._doc;
          res.json({...data}).status(200);
      } catch (e) {
          res.status(501).json('Не выполнено')
      }
   };

   async delete (req, res) {
      try {
          await Order.findByIdAndDelete({_id: req.params.id});
          return res.status(200).json({message: "Заказ удален"});
      } catch (e) {
          res.status(501).json({message: e})
      }
   };

   async getOne (req, res) {
        try {
            const cart = await Order.findById({userId: req.params.userId})
            const {...data} = cart._doc;
            return res.json({...data}).res.status(200)
        } catch (e) {
           res.status(501).json('Не выполнено')
        }
   }
    async getAll (req, res) {
        try {
            const carts = await Order.find()
            res.json(carts).status(200)
        }catch (e) {
            res.status(501).json('Не выполнено')
        };
    }
    
    async monthStat (req, res) {
        const productId = req.query.pid;
        const date = new Date();
        const lastMonth = new Date(date.setMonth(date.getMonth() -1));
        const previousMonth = new Date (new Date().setMonth(lastMonth.getMonth() -1));
       try{
           const income = await Order.aggregate([
               {
                   $match: { createdAt: { $gte: previousMonth },
                       ...(productId && { products: { $elemMatch: { productId } },
                       }),
                   },
               },
               {
                   $project: { month: { $month: "$createdAt" }, sales: "$amount", },
               },
               {
                   $group: { _id: "$month", total: { $sum: "$sales" }, },
               },
           ]);
           res.status(200).json(income)
       }
       catch (e) {
           res.status(501).json({message: e})
       }
       
    }

}

export default new OrderControllers();

//$match: {,
//                     })