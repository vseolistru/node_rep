import User from '../models/User.js';
import bcrypt from 'bcryptjs';

const strongPassword = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})")


class UserControllers {

    async stats (req, res) {
        const date = new Date();
        const  lastYear = new Date(date.setFullYear(date.getFullYear() -1));
        try{
            const data = await User.aggregate([
                {$match : {createdAt: {$gte: lastYear}}},
                {
                    $project:{month: {$month: "$createdAt"}}
                },
                {
                    $group:{_id: "$month", total:{$sum: 1}},
                },
            ]);
            res.status(200).json(data)
        }
        catch (e){
            res.status(501).json({message: e})
        }
    }

    async getAll(req, res) {
        try {
            //?new=true
            const query = req.query.new;
            const users = query ? await User.find().sort({_id:-1}).limit(15) : await User.find()
            res.json(users)
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async getOne(req, res) {
        try {
            const user = await User.findById({_id: req.params.id})
            if (!user) {
                return res.status(404).json('Пользователь не найден')
            }
            return res.json(user)
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async update(req, res) {
        try {
            const {id} = req.params
            const {email, password} = req.body
            if (!email || !password) {
                return res.status(403).json('Значения полей email и password не должны быть пустыми')
            }
            if (password.length < 8) {
                return res.status(403).json('Пароль должен содержать 8 символов')
            }
            if (!strongPassword.test(password)) {
                return res.status(403).json('Пароль должен содержать 1 спецсимвол, 1 символ верхнего регистра, 1 число')
            }
            const hashPassword = await bcrypt.hashSync(password)
            const updateUser = await User.findByIdAndUpdate(id, {email, password: hashPassword})
            const {...data} = updateUser._doc;
            return res.json({...data}).status(200)
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async delete (req, res) {
        try{
            const user = await User.findByIdAndDelete({_id: req.params.id})
            return res.status(200).json({message: "Пользователь удален"})
        }
        catch (e) {
            res.status(501).json({message: e})
        }
    }
}

export default new UserControllers()