import Cart from "../models/Cart.js";

class CartControllers {
    async create (req, res) {
        try{
            const newCart = new Cart (req.body);
            const savedCart = await newCart.save();
            return res.json({savedCart}).status(200);
        }
        catch (e) {
            res.status(500).json("Something went wrong")
        }
    }

    async update (req, res) {
        try {
            const updateCart = await Cart.findByIdAndUpdate(
                req.params.id,
                {$set: req.body}, {new: true}
            );
            const {...data} = updateCart._doc;
            res.json({...data}).status(200);
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async delete (req, res) {
        try {
            await Cart.findByIdAndDelete({_id: req.params.id})
            return res.status(200).json({message: "Корзина удалена"})
        } catch (e) {
            res.status(501).json({message: e})
        }
    }

    async getOne (req, res) {
        try {
            const cart = await Cart.findById({userId: req.params.userId})
            const {...data} = cart._doc;
            return res.json({...data}).res.status(200)
        } catch (e) {
           res.status(501).json('Не выполнено')
        }
    }

    async getAll (req, res) {
        try {
            const carts = await Cart.find()
            res.json(carts).status(200)
        }catch (e) {
            res.status(501).json('Не выполнено')
        };
    }
}

export default new CartControllers();