import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import {v4} from 'uuid';
import mailService from "../service/mailService.js";
import jwt from 'jsonwebtoken';

const generateJwt = (id, email, isAdmin) => {
    return jwt.sign({id, email, isAdmin}, process.env.SECRET_KEY, {expiresIn: '3d'})
}

const strongPassword = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})");
const emailValidator = new RegExp("^([A-Za-z0-9_\\-\\.])+\\@([A-Za-z0-9_\\-\\.])+\\.([A-Za-z]{2,4})");

class AuthControllers {
    //register
    async registration(req, res) {
        try {
            const {username, email, password} = req.body
            if (!email || !password || !username) {
                return res.status(403).json('Значения полей username, email и password не должны быть пустыми')
            }
            if (!emailValidator.test(email)) {
                return res.status(403).json('Email должен содержать - @ и домен')
            }
            if (password.length < 8) {
                return res.status(403).json('Пароль должен содержать 8 символов')
            }
            if (!strongPassword.test(password)) {
                return res.status(403).json('Пароль должен содержать 1 спецсимвол, 1 символ верхнего регистра, 1 число')
            }
            const candidate = await User.findOne({email})
            if (candidate) {
                return res.status(403).json('Пользователь с таким email уже существует')
            }

            const hashPassword = await bcrypt.hashSync(password);
            const activationLink = v4();
            await mailService.sendActivationMail(email, `${process.env.API_URL}/api/users/activate/${activationLink}`);
            const user = await User.create({email, username, activationLink, password: hashPassword});
            const token = generateJwt(user.id, user.email, user.isAdmin)
            return res.json({user, token});
        } catch (e) {
            res.status(500).json("Something went wrong");
        }
    }

    async activate (req, res){
        try {
            const activationLink = req.params.link
            const  userLink = await User.findOne({activationLink})
            if(!userLink){
                res.status(500).json('Некорректная ссылка')
            }
            userLink.isActivated = true
            await userLink.save()
            return res.redirect('http://localhost:5000/')
        }
        catch (e){
            res.status(500).json('is not saved')
        }
    }

    async login (req, res) {
        try {
            const {username, password} = req.body
            const user = await User.findOne({username})
            if (!user){
                return res.status(401).json(`user ${username} does not exist`)
            }
            let comparePassword = bcrypt.compareSync(password, user.password)
            if (!comparePassword){
                return res.status(401).json(`user pass is a wrong`)
            }
            const token = generateJwt(user.id, user.email, user.isAdmin)
            const {...data} = user._doc;
            return res.status(200).json({...data, token})
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }
//_id:user._id, username: user.username, email: user.email
}

export default new AuthControllers()