import Product from "../models/Product.js";
import path from "path";
import {v4} from 'uuid';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


class ProdControllers {

    async create(req, res) {
        try {
            const {title, catId, brandId, description, price, size, colors, inStock} = req.body;
             if (!title || !catId || !brandId || !description || !price || !size || !colors ) {
                 return res.status(403).json('Значения полей товаров, не должны быть пустыми')
             }
            const {img} = req.files
            let fileName = v4()+".jpg"
            await img.mv(path.resolve(__dirname, '..', 'static', fileName))
            const product = await Product.create({
                title,
                catId,
                brandId,
                description,
                price,
                size,
                colors,
                img:fileName,
                inStock
            });
            return res.json({product}).status(200);
        } catch (e) {
            res.status(500).json("Something went wrong")
        }
    }

    async update(req, res) {
        try {
            const updateProd = await Product.findByIdAndUpdate(
                req.params.id,
                {$set: req.body}, {new: true}
            );
            const {...data} = updateProd._doc;
            res.json({...data}).status(200);
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async delete(req, res) {
        try {
            await Product.findByIdAndDelete({_id: req.params.id})
            return res.status(200).json({message: "Товар удален"})
        } catch (e) {
            res.status(501).json({message: e})
        }
    }

    async getOne(req, res) {
        try {
            const product = await Product.findById({_id: req.params.id})
            if (!product) {
                return res.status(404).json('Товар не найден')
            }
            const {...data} = product._doc;
            return res.json({...data})
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

    async getAll(req, res) {
        try {
            const qNew = req.query.new;
            const qCatId = req.query.catId;
            const qBrandId = req.query.brandId;
            let products;
            if(qNew) {
                products = await Product.find().sort({createdAt: -1}).limit(1);
            }
            else if (qCatId) {
                products = await Product.find({catId:{$in:qCatId,},});
            }
            else if (qBrandId) {
                products = await Product.find({brandId: {$in: qBrandId}});
            }
            else{
                products = await Product.find();
            }
            return res.json(products).status(200)
        } catch (e) {
            res.status(501).json('Не выполнено')
        }
    }

}
export default new ProdControllers();