import express from "express";
import {verifyToken, verifyTokensAndAdmin, verifyTokensAndAuthorization} from "../middleware/verifyTokens.js";
import orderControllers from "../Controllers/orderControllers.js";

const orderRoute = express.Router();

orderRoute.post('/', verifyToken, orderControllers.create);
orderRoute.put('/', verifyTokensAndAdmin, orderControllers.update);
orderRoute.delete('/:id',verifyTokensAndAdmin, orderControllers.delete);
orderRoute.get('/find/:userId', verifyTokensAndAuthorization, orderControllers.getOne);
orderRoute.get('/', verifyTokensAndAdmin, orderControllers.getAll);
orderRoute.get('/income', verifyTokensAndAdmin, orderControllers.monthStat)

export default orderRoute;