import express from "express";
import categoryControllers from "../controllers/categoryControllers.js";
const categoryRoute = express.Router();

categoryRoute.post("/add", categoryControllers.create);

categoryRoute.get('/get', categoryControllers.getAll);

categoryRoute.get("/:id", categoryControllers.getOne);

categoryRoute.put("/update", categoryControllers.update);

categoryRoute.delete("/delete/:id", categoryControllers.delete);

export default categoryRoute