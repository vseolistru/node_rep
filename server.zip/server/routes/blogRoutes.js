import express from "express";
import blogControllers from "../controllers/blogControllers.js";
const blogRoute = express.Router();

blogRoute.post("/add", blogControllers.add)

blogRoute.get("/get", blogControllers.getAll)

blogRoute.get("/:id", blogControllers.getOne)

blogRoute.put("/update", blogControllers.update)

blogRoute.delete("/delete/:id", blogControllers.delete)

export default blogRoute;


