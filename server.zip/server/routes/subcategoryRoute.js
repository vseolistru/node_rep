import express from "express";
import subcategoryControllers from "../controllers/subcategoryControllers.js";


const subcategoryRoute = express.Router();

subcategoryRoute.post("/add", subcategoryControllers.create)

subcategoryRoute.get('/get', subcategoryControllers.getAll)

subcategoryRoute.get("/:id", subcategoryControllers.getOne)

subcategoryRoute.put("/update", subcategoryControllers.update)

subcategoryRoute.delete("/delete/:id", subcategoryControllers.delete)

export default subcategoryRoute;