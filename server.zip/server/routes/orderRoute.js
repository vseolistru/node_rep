import express from "express";
import Order from "../models/orderModels.js";
import orderControllers from "../controllers/orderControllers.js";
const orderRoute = express.Router();

orderRoute.post("/add", async (req,res)=>{
    try {
        const newOrder = new Order({
            orderItems: req.body.orderItems.map((x) => ({...x, product: x._id})),
            userId: req.body._id,
            subTotal: req.body.subTotal,
            taxPrice: req.body.taxPrice,
            name: req.body.name,
            email: req.body.email,
            address: req.body.address,
            phone: req.body.phone,
            totalPrice: req.body.totalPrice,
            isPaid: req.body.isPaid,
            isShipped: req.isShipped

        })
        const order = await newOrder.save();
        res.status(201).send({message: 'New Order Created!', order})
    }
    catch (e) {
        res.status(501).json('Не выполнено')
    }
});

orderRoute.get('/get', async (req, res)=>{
    try{
        const orders = Order.find()
        res.json(orders).status(201)
    }
    catch (e) {
        res.status(501).json('Не выполнено')
    }

});

orderRoute.get('mine/:id', orderControllers.getMine);

orderRoute.get('/:id', orderControllers.getOne);

// orderRoute.put("/update", orderControllers.update);
//
// orderRoute.delete("/delete/:id", orderControllers.delete);

export default orderRoute;