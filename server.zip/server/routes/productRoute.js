import express from "express";
import productControllers from "../controllers/productControllers.js";
const productRoute = express.Router();

productRoute.post("/add", productControllers.create);

productRoute.get("/get", productControllers.getAll);

productRoute.get("/:id", productControllers.getOne);

productRoute.put("/update", productControllers.update);

productRoute.delete("/delete/:id", productControllers.delete);

export default productRoute;