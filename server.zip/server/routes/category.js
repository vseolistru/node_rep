import express from "express";
import {verifyTokensAndAdmin} from "../middleware/verifyTokens.js";
import Category from "../models/Category.js"

const categoryRoute = express.Router();

categoryRoute.post('/', verifyTokensAndAdmin, async (req,res ) => {
    try {
        const catName = new Category(req.body)
        await catName.save()
        return res.json(catName).status(200)
    } catch (e) {
         return res.status(500).json(e)
    }
});

categoryRoute.get('/', async (req, res)=>{
    try {
        const category = await Category.find();
        res.json(category).status(200);
    }
    catch (e) {
        return res.json({message: e}).status(500);
    }
});

export default categoryRoute