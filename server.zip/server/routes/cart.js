import express from "express";
import {verifyToken, verifyTokensAndAdmin, verifyTokensAndAuthorization} from "../middleware/verifyTokens.js";
import cartControllers from "../Controllers/cartControllers.js";
const cartRoute = express.Router();

cartRoute.post('/', verifyToken, cartControllers.create);
cartRoute.put('/:id', verifyTokensAndAuthorization, cartControllers.update);
cartRoute.delete("/:id", verifyTokensAndAuthorization, cartControllers.delete);
cartRoute.get('/find/:UserId', verifyTokensAndAuthorization, cartControllers.getOne);
cartRoute.get('/', verifyTokensAndAdmin, cartControllers.getAll);

export default cartRoute;