import express from "express";
import data from "../data.js";
import User from "../models/userModels.js";
import Blog from "../models/blodModels.js";
import Product from "../models/productModels.js";
import Category from "../models/categoryModels.js";
import Subcategory from "../models/subcategoryModels.js";
import Ratting from "../models/rattingModels.js";

const seedRoute = express.Router();

seedRoute.get('/', async (req, res) =>{
    await User.remove({});
    const createdUser = await User.insertMany(data.users);

    await Blog.remove({});
    const createBlog = await Blog.insertMany(data.blogs);

    await Category.remove({});
    const createCategory = await Category.insertMany(data.categories);

    await Subcategory.remove({});
    const createSubcategory = await Subcategory.insertMany(data.subcategory);

    await Ratting.remove({});
    const createRatting = await Ratting.insertMany(data.ratting);

    await Product.remove({});
    const createProduct = await Product.insertMany(data.products);

    res.send({createdUser ,createBlog, createProduct, createCategory,createSubcategory, createRatting});

});
export default seedRoute;