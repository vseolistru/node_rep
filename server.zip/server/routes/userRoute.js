import express from "express";
import userControllers from "../controllers/userControllers.js";


const userRoute = express.Router();
userRoute.post('/registration', userControllers.registration)

userRoute.post('/login', userControllers.login)

userRoute.get('/activate/:link', userControllers.activate)

userRoute.get('/all', userControllers.getAll)

userRoute.get('/:id', userControllers.getOne)

userRoute.put('/update', userControllers.update)


export default userRoute;