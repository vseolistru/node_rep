import express from "express";
import {verifyTokensAndAdmin} from "../middleware/verifyTokens.js";
import Brand from "../models/Brands.js"

const brandRoute = express.Router();

brandRoute.post('/', verifyTokensAndAdmin, async (req, res)=>{
    try {
        const {brandId, brandName} = req.body;
        if (!brandId || !brandName) {
            return res.status(403).json('Значения полей бренда, не должны быть пустыми')
        }
        const brand = await Brand.create({brandId, brandName})
        return res.json(brand).status(200)
    } catch (e) {
        return res.json({message: e}).status(500)
    }
});

brandRoute.get('/', async (req, res)=>{
    try {
        const brand = await Brand.find();
        res.json(brand).status(200);
    }
    catch (e) {
        return res.json({message: e}).status(500);
    }
});

export default brandRoute