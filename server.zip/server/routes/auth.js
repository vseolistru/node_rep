import express from "express";
import authControllers from "../Controllers/authControllers.js";


const authRouter = express.Router();

authRouter.post("/register", authControllers.registration)
authRouter.post("/login", authControllers.login)
authRouter.get('/activate/:link', authControllers.activate)

export default authRouter;