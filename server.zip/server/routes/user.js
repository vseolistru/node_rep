import express from "express";
import userControllers from "../Controllers/userControllers.js";
import {verifyTokensAndAuthorization, verifyTokensAndAdmin} from "../middleware/verifyTokens.js";
const userRoute = express.Router();


userRoute.put('/:id',verifyTokensAndAuthorization, userControllers.update);
userRoute.get('/find/:id', verifyTokensAndAdmin, userControllers.getOne);
userRoute.get('/all', verifyTokensAndAdmin, userControllers.getAll);
userRoute.delete('/:id',verifyTokensAndAuthorization, userControllers.delete);
userRoute.get('/stats', verifyTokensAndAdmin, userControllers.stats);

export default userRoute;