import express from "express";
import {verifyTokensAndAdmin} from "../middleware/verifyTokens.js";
import prodControllers from "../Controllers/prodControllers.js";
const productRoute = express.Router();

productRoute.post('/', verifyTokensAndAdmin, prodControllers.create);
productRoute.put('/:id', verifyTokensAndAdmin, prodControllers.update);
productRoute.delete('/:id', verifyTokensAndAdmin, prodControllers.delete);
productRoute.get('/find/:id', prodControllers.getOne);
productRoute.get('/', prodControllers.getAll);

export default productRoute;