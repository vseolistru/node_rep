import express from "express";
import rattingControllers from "../controllers/rattingControllers.js";
const rattingRoute = express.Router();

rattingRoute.post("/add", rattingControllers.create)

rattingRoute.get('/get', rattingControllers.getAll)

rattingRoute.get("/:id", rattingControllers.getOne)

rattingRoute.put("/update", rattingControllers.update)

rattingRoute.delete("/delete/:id", rattingControllers.delete)

export default rattingRoute