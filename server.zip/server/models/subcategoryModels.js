import mongoose from 'mongoose'

const subCategorySchema = new mongoose.Schema({
    checked: {type: Boolean, required: true},
    label: {type: String, required: true}
}, {timestamps:true})

const Subcategory = mongoose.model('Subcategory',subCategorySchema)
export default Subcategory;