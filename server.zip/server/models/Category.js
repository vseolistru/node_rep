import mongoose from 'mongoose';

const CategorySchema = new mongoose.Schema({
    catId:{type:Number, required: true, unique: true},
    catName:{type:String, required: true}

}, {timestamps:true})

const Category = mongoose.model('Category' ,CategorySchema);
export default Category;