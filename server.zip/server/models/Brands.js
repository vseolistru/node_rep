import mongoose from 'mongoose';

const BrandSchema = new mongoose.Schema({
    brandId:{type:Number, required: true, unique: true},
    brandName:{type:String, required: true}

}, {timestamps:true})

const Brand = mongoose.model('Brand' ,BrandSchema);
export default Brand;