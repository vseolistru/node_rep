import mongoose from 'mongoose';

const ProductSchema = new mongoose.Schema({
    title:{type:String, required: true, unique: true},
    description:{type:String, required: true},
    img:{type:String, required: true},
    catId: {type:Number, required:true},
    brandId:{type:Number, required:true},
    colors: {type:Array},
    size: {type:Array},
    price: {type:Number, required:true},
    inStock: {type:Boolean, default:true},

}, {timestamps:true})

const Product = mongoose.model('Product' ,ProductSchema);
export default Product;