import mongoose from 'mongoose'

const RattingSchema = new mongoose.Schema({
    value: {type: String, required: true},
    label: {type: String, required: true}
}, {timestamps:true})

const Ratting = mongoose.model('Ratting',RattingSchema)
export default Ratting;