import jwt from 'jsonwebtoken';


export const verifyToken = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(' ')[1]
        if (!token) {
            return res.status(401).json({message: "Пользователь не авторизован"})
        }
        const decoded = jwt.verify(token, process.env.SECRET_KEY)
        req.user = decoded
        next()
    }
    catch (e) {
        res.status(403).json({message:"Инвалидный токен"})
    }
}

export const verifyTokensAndAuthorization = (req, res, next) => {
    verifyToken (req, res, ()=>{
        if(req.user.id === req.params.id || req.user.isAdmin){
            next();
        }
        else {
            res.status(403).json({message:"Запрещено"})
        }
    })
}

export const verifyTokensAndAdmin = (req, res, next) => {
    verifyToken (req, res, ()=>{
        if(req.user.isAdmin){
            next();
        }
        else {
            res.status(403).json({message:"Запрещено"})
        }
    })
}